How to use MiniShare:

1.) Drag and drop files on the program.
2.) Select the files by left clicking, you can select multiple files.
3.) Right click and select "Copy URL(s) to Clipboard."
4.) The clipboard now contains one or more URLs that people can use to access
    the files on you computer (with web browser etc.).
5.) The files are available as long as the program is running on you machine.
6.) Remove files the same way but selecting "Remove shared file(s)."

Read the included documentation for more help (found in
Start menu>Programs>MiniShare).

    http://www.kolumbus.fi/xtmb/minishare/
